package edu.itc.i4.gic.library;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class HomeController {
   @GetMapping(path="/")
	public String index() {
	  return "Hello Hun Ravit."  ;
   }
   @GetMapping(path="/tp14/task1")
	public String task1() {
	  return "<h1>Welcome to tp14 Task</h1>";
  }
}

package edu.itc.i4.gic.library;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Task3_5Controller {
	 @GetMapping("/tp14/task3")
     public String index() {
   	  return "task3";
     }
	 @GetMapping("/tp14/task4")
     public String index2() {
   	  return "task4";
     }
	 @GetMapping("/tp14/task5")
     public String index3() {
   	  return "task5";
     }
}
